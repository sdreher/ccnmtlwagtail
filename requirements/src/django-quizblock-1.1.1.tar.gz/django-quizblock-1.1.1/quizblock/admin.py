from models import Response, Submission
from django.contrib import admin

admin.site.register(Response)
admin.site.register(Submission)
