# flake8: noqa
from test_models import *
from test_templatetags import *
from test_reports import *
from test_views import *
